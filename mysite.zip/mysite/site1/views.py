from django.http import HttpResponse, HttpResponseNotFound, Http404
from django.shortcuts import render, redirect, get_object_or_404
from .models import *
from django.views.generic import ListView

menu = [{'title': "About site", 'url_name': 'about'},
    {'title': "Add a statement", 'url_name': 'add_page'},
    {'title': "Contacts", 'url_name': 'contact'},
]


def BoysHome(LastView):
    model = Boys
    template_name = 'site1/index.html'


def index(request):
    posts = Boys.objects.all()

    context = {
        'posts': posts,
        'menu': menu,
        'title': "Main site",
        'cat_selected': 0
    }
    return render(request, 'site1/index.html', context=context)

def about(request):
    return render(request, 'site1/about.html', {'menu': menu, 'title': 'About'})


def addpage(request):
    return HttpResponse("Adding a statement")


def contact(request):
    return HttpResponse("Contacts")


def login(request):
    return HttpResponse("Login")


def pageNotFound(request, exception):
    return HttpResponseNotFound('<h1>Page was not found</h1>')


def show_post(request, post_id):
    post = get_object_or_404(Boys, pk=post_id)

    context = {
        'post': post,
        'menu': menu,
        'title': post.title,
        'cat_selected': post.cat
    }

    return render(request, 'site1/post.html', context=context)


def show_category(request, cat_id):
    posts = Boys.objects.filter(cat_id=cat_id)


    if len(posts) == 0:
        raise Http404()

    context = {
        'posts': posts,
        'menu': menu,
        'title': "Отображение по рубрикам",
        'cat_selected': cat_id
    }

    return render(request, 'site1/index.html', context=context)
